### This script is used to get the pairwise MANOVA and the Tukey's honest significance test to compare MInOSSE vs. hull methods ####

#rm(list=ls(all=TRUE))
#ls()
eco_sims_results_path_coc_loc<-results_path
eco_sims_results_path_no_coc<-results_path_no_coc

files_names_coc_loc<-list.files(eco_sims_results_path_coc_loc,pattern = "stats")
files_names_no_coc<-list.files(eco_sims_results_path_no_coc,pattern = "stats")

stats_coc_loc<-lapply(files_names_coc_loc,function(x)read.table(paste(eco_sims_results_path_coc_loc,x,sep="")))
stats_no_coc<-lapply(files_names_no_coc,function(x)read.table(paste(eco_sims_results_path_no_coc,x,sep="")))


lapply(stats_coc_loc,function(x){data.frame(x,coc=TRUE)->y;
  return(y)})->TRUE_coc
lapply(stats_no_coc,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc

names(TRUE_coc)<-files_names_coc_loc
names(FALSE_coc)<-files_names_no_coc

sims<-c("100km","200km","300km","semi","mean")

TRUE_coc<-TRUE_coc[unlist(sapply(sims,function(x)grep(x,names(TRUE_coc),useBytes=TRUE) ))]
FALSE_coc<-FALSE_coc[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc)) ))]


lapply(seq(1:5),function(x)data.frame(TRUE_coc[[x]],cell_size=sims[x]))->manova_TRUE_coc
lapply(seq(1:5),function(x)data.frame(FALSE_coc[[x]],cell_size=sims[x]))->manova_FALSE_coc



gimme.data<-function(stats){
  stats->stats_4_boxplot
  lapply(stats_4_boxplot[,-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)cbind(stats_4_boxplot[,which(colnames(stats_4_boxplot)%in%c("spec","occ"))],x))->ciccio_box
  do.call(rbind,ciccio_box)->ciccio_box
  lapply(colnames(stats_4_boxplot)[-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)rep(x,nrow(stats_4_boxplot)))->col_names_box
  unlist(col_names_box)->col_names_box
  data.frame(model_th=col_names_box,ciccio_box)->ciccio_box
  return(ciccio_box)  
}

lapply(manova_FALSE_coc,function(x)gimme.data(x))->anova_FALSE_coc
lapply(manova_TRUE_coc,function(x)gimme.data(x))->anova_TRUE_coc

#### MANOVA data #
do.call(rbind,manova_FALSE_coc)->manova_FALSE_coc
do.call(rbind,manova_TRUE_coc)->manova_TRUE_coc


library(usdm)
dataset<-rbind(manova_FALSE_coc,manova_TRUE_coc)


#### Permutational pairwise MANOVA is used to test if there are significant differences 
# between the different MInOSSE settings dealing with interpolation cell resolutions or the use of cooccurrence analysis  #### 
library(devtools)
#devtools::install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
library(pairwiseAdonis)
chosen_axis<-min(which(summary(pca_dataset<-prcomp(dataset[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset<-pca_dataset$x[,1:chosen_axis]
ado_res<-adonis(pca_dataset~coc+cell_size, data=dataset,method = "euclidean",permutations = 500,parallel=5)

# This is the output of the permutational pairwise MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using different interpolation cell resolutions or by using or not using cooccurrence analysis ###
#ado_res



### Here we perform ANOVA with PC1 axis of all the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods. 
# This analysis is performed for each interpolation cell resolution, separately.
# With the cooccurrence-based MInOSSE output # 
lapply(anova_TRUE_coc,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_TRUE_coc

anov_res_TRUE_coc<-lapply(new_anova_TRUE_coc,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
  })
## ANOVA results #
#anov_res_TRUE_coc

#####

#### Tukey
Tukey_res_TRUE_coc<-lapply(anov_res_TRUE_coc,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
## Tukey HSD results #
#Tukey_res_TRUE_coc


### Here we perform ANOVA with PC1 axis of all the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods.
# This analysis is performed for each interpolation cell resolution, separately.
# Without the cooccurrence-based MInOSSE output # 
lapply(anova_FALSE_coc,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_FALSE_coc

anov_res_FALSE_coc<-lapply(new_anova_FALSE_coc,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results#
#anov_res_FALSE_coc

#####

#### Tukey
Tukey_res_FALSE_coc<-lapply(anov_res_FALSE_coc,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
# Tukey HSD results #
Tukey_res_FALSE_coc



