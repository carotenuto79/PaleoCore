# By using this script the users can perform MInOSSE with the case studies reported in the main manuscript
#  
library(PaleoCore)
data(lgm)
library(raster)
raster(system.file("exdata/prediction_ground.gri", package="PaleoCore"))->prediction_ground



#### Geographic range reconstruction of Mummuthus primigeniuis in Eurasia from 24 kya to 14 kya ####
# First step: run minosse data to create the ecological predictors and select apart the target species occurrences
system.time(mam_minosse_dat<-minosse.data(
  obj=lgm,
  species_name="Mammuthus_primigenius",
  domain="land",
  coc.by="cell",
  min.occs=3,
  abiotic.covs=NULL,
  combine.covs=TRUE,   
  reduce_covs_by="pca",
  covs_th=0.95,
  c.size="mean",
  bkg.predictors="presence",
  min.bkg=100,
  sampling.by.distance=TRUE,
  prediction.ground=prediction_ground,
  crop.by.mcp=FALSE,
  projection=NULL,
  lon_0=NULL,
  lat_0=NULL,
  n.clusters="automatic",
  seed=625));gc();spplot(mam_minosse_dat[[2]])
## 

# Second step: running minosse.target by using the output of minosse.data in order to reconstruct
# target species geographic range.
system.time(mam_minosse_res<-minosse.target(
  resp=mam_minosse_dat[[1]],
  predictors=mam_minosse_dat[[2]],
  bkg="presence", 
  min.bkg = 100,
  n.sims=10, 
  sampling.by.distance=TRUE,
  n.folds=1, 
  n.sims.clusters="automatic",
  seed=625));gc()
mam_minosse_res$validation
minosse.poly(mam_minosse_res)
library(ggplot2)
minosse.plot(mam_minosse_res)





#### Capreolus capreolus. In this script the Roe deer geographic range was reconstructed since 24 kya instead of 130 kya
# because of we used a fully revised, not-yet buplished dataset for the longer time interva. Also in this restricted example the 
#results and reconstructions are still consistent with what reported in the main manuscript 

# First step: run minosse data to create the ecological predictors and select apart the target species occurrences
system.time(cap_minosse_dat<-minosse.data(
  obj=lgm,
  species_name="Capreolus_capreolus",
  domain="land",
  coc.by="locality",
  min.occs=3,
  abiotic.covs=NULL,
  combine.covs=FALSE,   
  reduce_covs_by="pca",
  covs_th=0.95,
  c.size="mean",
  bkg.predictors="presence",
  min.bkg=100,
  sampling.by.distance=TRUE,
  prediction.ground=NULL,
  crop.by.mcp=FALSE,
  projection="laea",
  lon_0=NULL,
  lat_0=NULL,
  n.clusters="automatic",
  seed=625));gc();spplot(cap_minosse_dat[[2]])
## 


# Second step: running minosse.target by using the output of minosse.data in order to reconstruct
# target species geographic range.
system.time(cap_minosse_res<-minosse.target(
  resp=cap_minosse_dat[[1]],
  predictors=cap_minosse_dat[[2]],
  bkg="presence", 
  min.bkg = 100,
  n.sims=10, 
  sampling.by.distance=TRUE,
  n.folds=1, 
  n.sims.clusters="automatic",
  seed=625));gc()
cap_minosse_res$validation
minosse.poly(cap_minosse_res)
library(ggplot2)
minosse.plot(cap_minosse_res)








