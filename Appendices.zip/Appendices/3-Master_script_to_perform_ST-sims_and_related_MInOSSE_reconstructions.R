#### This is the main script that runs all at once all the ST-sims as described in the main manuscript
# and performs the related MInOSSE geographic ranges reconstrictions. The user has to install the required
# packages (described below) and enter the path to the folder where appendices are stored ("appendices_folder")
# and where to store all the simulations results (my.path). An additional parameter to set is the number of 
# folds for AUC-based cross-validations. A default parameter is n.folds=1, which speeds up MInOSSE 
# predictions without affecting any result but the AUC computation (see below).

install.packages(c("sdmvspecies","rgeos","scales","KernSmooth","adehabitatLT"))
#library(devtools) 
#install_github("paleocore-lab/PaleoCore") # run this line only the first time you have to install PaleoCore.

rm(list=ls(all=TRUE))

library(PaleoCore)
library(spatstat)
library(rworldmap)
library(maptools)
library(rgdal) 
library(adehabitatLT)
library(sp)
library(raster)
library(foreach)
library(doSNOW)
library(doParallel) 
library(rgeos)


#### General setting ####
memory.size(max=TRUE)
#### Enter the path to the folder where you stored all appendices
appendices_folder<-"H:/Appendices/" # ending slash required!

#### Enter the path where you want to store all the simulations ####
my.path<-"H:/Tests_minosse/"  # ending slash required!

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path_coc_loc_100_100<-paste(my.path,"st-sims/coc_loc/spec100/locs100/",sep="") 
dir.create(dir.path_coc_loc_100_100, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 200 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path_coc_loc_100_200<-paste(my.path,"st-sims/coc_loc/spec100/locs200/",sep="") 
dir.create(dir.path_coc_loc_100_200, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc_100_100<-paste(my.path,"st-sims/no_coc/spec100/locs100/",sep="") 
dir.create(dir.path_no_coc_100_100, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 200 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc_100_200<-paste(my.path,"st-sims/no_coc/spec100/locs200/",sep="") 
dir.create(dir.path_no_coc_100_200, showWarnings = TRUE, recursive = TRUE)







#### Set the number of folds for AUC-based cross-validations of MInOSSE models.
# AUC-based cross-validations are additional analyses we allow to perform to test MInOSSE models performance
# and that add to the internal 5-folds cross-validation of Regression Kriging model performance measure.
# AUC-based cross-validations increase MInOSSE computational time as each pseudo-absences simulation 
# (default number = 10) is repeated as many times as the folds' number. As a consequence, we set 1 fold to 
# speed up MInOSSE, but the AUC values presented in the main manuscript (and related supplementary 
# informations) are based on a 5 folds AUC-based cross-validation procedure (see the main text).

n.folds<-1


#### By using cooccurrence analysis ####
##  Simulations of  100 speciess and 100 fossil localities considering, separately, highly clustered, moderately clustered,
# random and uniform spatial distributions, of both species' centres of distribution and fossil localities.
source(paste(appendices_folder,"st_sims_coc_loc_100specs_100locs.R",sep=""))
gc()

##  Simulations of  100 speciess and 200 fossil localities considering, separately, highly clustered, moderately clustered,
# random and uniform spatial distributions, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_coc_loc_100specs_200locs.R",sep=""))
gc()






#### Without cooccurrence analysis ####
##  Simulations of  100 speciess and 100 fossil localities considering highly clustered, moderately clustered,
# random and uniform spatial distributions, separately, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_no_coc_100specs_100locs.R",sep=""))
gc()

##  Simulations of  100 speciess and 200 fossil localities considering highly clustered, moderately clustered,
# random and uniform spatial distributions, separately, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_no_coc_100specs_200locs.R",sep=""))
gc()


