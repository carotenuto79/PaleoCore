# This is a master script that you can use to execute all the other scripts
# running the all the methods'performance computation and comparison. 
# The first step consists of installing the last version of Rtools and the package "pairwiseAdonis". 
# To this aim, here we report the pairwiseAdonis package creator instructions:
# For linux
# make sure you have devtools installed and loaded, for windows also install Rtools
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
# 
# That's it
# 
# Or...
# 
# For windows
# first install Rtools from here https://cran.r-project.org/bin/windows/Rtools/
# 
# in R install devtools
# 
# install.packages('devtools')
# 
# load devtools
# 
# library(devtools)
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")


# Packages to install:
install.packages(c("alphahull", "geosphere","ConR"))
# Setting the maximum memory size available to R
rm(list=ls(all=TRUE))
memory.size(max=TRUE)


#### Enter the path to the folder where you stored all appendices
appendices_folder<-"E/Appendices/" # ending slash required!

#### Enter the path where you stored all the simulations ####
my.path<-"E:/Tests_minosse/"  # ending slash required!


#### Enter the path where you want to save all the methods' performance metrics when considering cooccurrence analysis ####
results_path<-paste(my.path,"eco-sims/LGM_results/",sep="")
dir.create(results_path, showWarnings = TRUE, recursive = TRUE)

#### Enter the path where you want to save all the methods' performance metrics when NOT considering cooccurrence analysis ####
results_path_no_coc<-paste(my.path,"eco-sims/LGM_no_coc_results/",sep="")
dir.create(results_path_no_coc, showWarnings = TRUE, recursive = TRUE)

#### By using cooccurrence analysis ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_semimean_coc_loc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_mean_coc_loc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_100km_coc_loc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_200km_coc_loc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_300km_coc_loc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 




#### Without using cooccurrence analysis ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_semimean_no_coc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_mean_no_coc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_100km_no_coc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_200km_no_coc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_300km_no_coc.R",sep="/"), encoding = 'UTF-8')
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 




### This script is used to perform the pairwise MANOVA and the Tukey's honest significance test to compare MInOSSE vs. hull methods ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"ANOVA_MANOVA_tests_ECO-sims.R",sep="/"), encoding = 'UTF-8')
gc()

# This is the output of the permutational MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using different interpolation cell resolutions or by using or not using cooccurrence analysis ###
# No need to perform pairwise test here.
ado_res


# ANOVA results when considering cooccurrence analysis#
names(anov_res_TRUE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_TRUE_coc,function(x)x$aov_summary)->anov_res_TRUE_coc_res
anov_res_TRUE_coc_res$`100km`
anov_res_TRUE_coc_res$`200km`
anov_res_TRUE_coc_res$`300km`
anov_res_TRUE_coc_res$semi
anov_res_TRUE_coc_res$mean

# Tukey HSD results when considering cooccurrence analysis#
names(Tukey_res_TRUE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_TRUE_coc$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values



# ANOVA results without cooccurrence analysis#
names(anov_res_FALSE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_FALSE_coc,function(x)x$aov_summary)->anov_res_FALSE_coc_res
anov_res_FALSE_coc_res$`100km`
anov_res_FALSE_coc_res$`200km`
anov_res_FALSE_coc_res$`300km`
anov_res_FALSE_coc_res$semi
anov_res_FALSE_coc_res$mean

# Tukey HSD results without cooccurrence analysis#
names(Tukey_res_FALSE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_FALSE_coc$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

