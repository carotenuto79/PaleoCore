#### This is the main script that runs all at once all the Eco-sims as described in the main manuscript
# and performs the related MInOSSE geographic ranges reconstrictions. The user has to install the required
# packages (described below) and enter the path to the folder where appendices are stored ("appendices_folder")
# and where to store all the simulations results (my.path). An additional parameter to set is the number of 
# folds for AUC-based cross-validations. A default parameter is n.folds=1, which speeds up MInOSSE 
# predictions without affecting any result but the AUC computation (see below).

rm(list=ls(all=TRUE))
library(devtools)
install_github("paleocore-lan/PaleoCore")
install.packages(c("sdmvspecies","rgeos","scales","KernSmooth"))

library(PaleoCore)
library(raster)
library(sdmvspecies)
library(foreach)
library(doSNOW)
library(doParallel)
library(rgeos)
library(scales)
library(KernSmooth)
library(dismo)


#### General setting ####
memory.size(max=TRUE)
#### Enter the path to the folder where you stored all appendices
appendices_folder<-"H:/Appendices/" # ending slash required!

#### Enter the path where you want to store all the simulations ####
my.path<-"H:/Tests_minosse/" # ending slash required!

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path<-paste(my.path,"eco-sims/coc_loc/",sep="") # Do not change this line!
dir.create(dir.path, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc<-paste(my.path,"eco-sims/no_coc/",sep="") # Do not change this line!
dir.create(dir.path_no_coc, showWarnings = TRUE, recursive = TRUE)


#### Download LGM time period bioclimatic variables and store files into "my.path" folder ####
# This files are used to extract climatic variables at simulated fossil sites to generate 
# ecologically and climatically plausible virtual species simulations (see the main manuscript). 
download.file("http://biogeo.ucdavis.edu/data/climate/cmip5/lgm/cclgmbi_10m.zip", paste(my.path,"cclgmbi_10m.zip",sep=""))
unzip(zipfile=paste(my.path,"cclgmbi_10m.zip",sep=""),exdir=paste(my.path,"LGM",sep=""))

#### Set the number of folds for AUC-based cross-validations of MInOSSE models.
# AUC-based cross-validations are additional analyses we allow to perform to test MInOSSE models performance
# and that add to the internal 5-folds cross-validation of Regression Kriging model performance measure.
# AUC-based cross-validations increase MInOSSE computational time as each pseudo-absences simulation 
# (default number = 10) is repeated as many times as the folds' number. As a consequence, we set 1 fold to 
# speed up MInOSSE, but the AUC values presented in the main manuscript (and related supplementary 
# informations) are based on a 5 folds AUC-based cross-validation procedure (see the main text).

n.folds<-1


clus_num<-"automatic" # set the number of clusters to use for parallel computation. You can set "automatic" in order to 
                      # allow MInOSSE using all the available clusters minus 1 


#### By using cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
#rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path","dir.path_no_coc"))])
source(paste(appendices_folder,"eco_sims_coc_loc_mean.R",sep=""))
gc() # 18:05 18/7/2019

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_semimean.R",sep=""))
gc() # 00:38 19/7/2019

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_100km.R",sep=""))
gc() # 7:30 19/7/2019

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_300km.R",sep=""))
gc()





#### Without cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_mean.R",sep=""))
gc()

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_semimean.R",sep=""))
gc()

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_100km.R",sep=""))
gc()

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_300km.R",sep=""))
gc()

