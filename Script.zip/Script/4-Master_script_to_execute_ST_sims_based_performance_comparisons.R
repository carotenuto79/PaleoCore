# This is a master script that you can use to execute all the other scripts
# running the all the methods'performance computation and comparison. 
# The first step consists of installing the last version of Rtools and the package "pairwiseAdonis". 
# To this aim, here we report the pairwiseAdonis package creator instructions:
# For linux
# make sure you have devtools installed and loaded, for windows also install Rtools
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
# 
# That's it
# 
# Or...
# 
# For windows
# first install Rtools from here https://cran.r-project.org/bin/windows/Rtools/
# 
# in R install devtools
# 
# install.packages('devtools')
# 
# load devtools
# 
# library(devtools)
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")


# Packages to install:
install.packages(c("alphahull", "geosphere","ConR"))
# Setting the maximum memory size available to R
rm(list=ls(all=TRUE))
memory.size(max=TRUE)


#### Enter the path to the folder where you stored all appendices
appendices_folder<-"H:/Appendices/" # ending slash required!

#### Enter the path where you stored all the simulations ####
my.path<-"H:/Tests_minosse/" # ending slash required!


#### Enter the path where you want to save all the methods' performance metrics when considering cooccurrence analysis ####
results_path_100_200_coc_loc<-paste(my.path,"st-sims/100_200/ST_results/",sep="")
dir.create(results_path_100_200_coc_loc, showWarnings = TRUE, recursive = TRUE)

#### Enter the path where you want to save all the methods' performance metrics when NOT considering cooccurrence analysis ####
results_path_100_200_no_coc<-paste(my.path,"st-sims/100_200/ST_no_coc_results/",sep="")
dir.create(results_path_100_200_no_coc, showWarnings = TRUE, recursive = TRUE)


#### Enter the path where you want to save all the methods' performance metrics when considering cooccurrence analysis ####
results_path_100_100_coc_loc<-paste(my.path,"st-sims/100_100/ST_results/",sep="")
dir.create(results_path_100_100_coc_loc, showWarnings = TRUE, recursive = TRUE)

#### Enter the path where you want to save all the methods' performance metrics when NOT considering cooccurrence analysis ####
results_path_100_100_no_coc<-paste(my.path,"st-sims/100_100/ST_no_coc_results/",sep="")
dir.create(results_path_100_100_no_coc, showWarnings = TRUE, recursive = TRUE)




#### By using cooccurrence analysis with 100 species and 100 simulated fossil localities ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_clus_max_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_clus_min_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_random_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_uniform_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 


#### By using cooccurrence analysis with 100 species and 200 simulated fossil localities ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_clus_max_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_clus_min_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_random_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_uniform_coc_loc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 




#### Without cooccurrence analysis with 100 species and 100 simulated fossil localities ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_clus_max_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_clus_min_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_random_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_100locs_uniform_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 




#### Without cooccurrence analysis with 100 species and 200 simulated fossil localities ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_clus_max_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_clus_min_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_random_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"Models_performance_st-sims_100specs_200locs_uniform_no_coc.R",sep=""))
gc()
line_plot # a line plot showing the course of methods performance by varying the target species sample size
box_plot # A box plot comparing the medians and ranges of the considered methods 






### This script is used to perform the pairwise MANOVA and the Tukey's honest significance test to compare MInOSSE vs. hull methods ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path_100_200_coc_loc","results_path_100_200_no_coc","results_path_100_100_coc_loc","results_path_100_100_no_coc"))])
source(paste(appendices_folder,"ANOVA_MANOVA_tests_ST-sims.R",sep="/"))
gc()

# The output of the permutational MANOVA by using 100 species and 100 fossil localities without cooccurrence analysis (cooccurrence analysis
# found no significant relationships between coeval species, thereby we didn' use them for these analyses):
ado_res_100

# As the previous test fund signigicant differences, we performed pairwise permutational MANOVA too:
pw_ado_rest_100
# With the related post-hoc test Tukey multiple comparisons on PCA axes (see the main maniscript) to get a measure of the differences 
# between the several clusterization degrees:
tukey_100_locs_res




# The output of the permutational MANOVA by using 100 species and 200 fossil localities with and without cooccurrence analysis:
ado_res_200
# As the analysis found significant results we performed and the related pairwise permutational MANOVA too:
pw_ado_rest_200
# with the related post-hoc test Tukey multiple comparisons on PCA axes (see the main maniscript) to get a measure of the differences 
# between the several clusterization degrees:
tukey_200_locs_res






#### ANOVA and the related Tukey HSD test using data with 100 fossil localities to compare
# MInOSSE outputs to the other polygon-based methods (MInOSSE.others) and to test for significant
# differences between the used thresholds to "binarize" Regression Kriging output (MInOSSE.MInOSSE).
# The analysis is performed with the different spatial clusterization degrees taken separately.

# without cooccurrence analysis:
names(anov_res_no_coc_100)<-sims
anov_res_no_coc_100$clus_max$aov_summary
anov_res_no_coc_100$clus_min$aov_summary
anov_res_no_coc_100$random$aov_summary
anov_res_no_coc_100$uniform$aov_summary

names(Tukey_res_no_coc_100)<-sims
# Highly clustered
Tukey_res_no_coc_100$clus_max$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_no_coc_100$clus_max$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Moderately clustered
Tukey_res_no_coc_100$clus_min$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_no_coc_100$clus_min$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Random
Tukey_res_no_coc_100$random$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_no_coc_100$random$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Uniform
Tukey_res_no_coc_100$uniform$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_no_coc_100$uniform$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values



#### ANOVA and the related Tukey HSD test using data with 200 fossil localities to compare
# MInOSSE outputs to the other polygon-based methods (MInOSSE.others) and to test for significant
# differences between the used thresholds to "binarize" Regression Kriging output (MInOSSE.MInOSSE).
# The analysis is performed with the different spatial clusterization degrees taken separately.

# We only shows results yielded by using cooccurrence analyses because previous test showed no differences between using and not
# using the cooccurrence analysis:
names(anov_res_200_coc_loc)<-sims
anov_res_200_coc_loc$clus_max$aov_summary
anov_res_200_coc_loc$clus_min$aov_summary
anov_res_200_coc_loc$random$aov_summary
anov_res_200_coc_loc$uniform$aov_summary

names(Tukey_res_200_coc_loc)<-sims
# Highly clustered
Tukey_res_200_coc_loc$clus_max$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_200_coc_loc$clus_max$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Moderately clustered
Tukey_res_200_coc_loc$clus_min$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_200_coc_loc$clus_min$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Random
Tukey_res_200_coc_loc$random$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_200_coc_loc$random$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

# Uniform
Tukey_res_200_coc_loc$uniform$minosse.others # MInOSSE vs. polygon-based methods
Tukey_res_200_coc_loc$uniform$minosse.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values




