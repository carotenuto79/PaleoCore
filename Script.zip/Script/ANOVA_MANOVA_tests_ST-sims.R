#rm(list=ls(all=TRUE))
#ls()

#files_names_100_coc_loc<-list.files(results_path_100_100_coc_loc,recursive=TRUE,pattern = ".txt")
#stats_100_coc_loc<-lapply(files_names_100_coc_loc,function(x)read.table(paste(results_path_100_100_coc_loc,x,sep="")))

files_names_200_coc_loc<-list.files(results_path_100_200_coc_loc,recursive=TRUE,pattern = ".txt")
stats_200_coc_loc<-lapply(files_names_200_coc_loc,function(x)read.table(paste(results_path_100_200_coc_loc,x,sep="")))


files_names_100_no_coc<-list.files(results_path_100_100_no_coc,recursive=TRUE,pattern = ".txt")
stats_100_no_coc<-lapply(files_names_100_no_coc,function(x)read.table(paste(results_path_100_100_no_coc,x,sep="")))

files_names_200_no_coc<-list.files(results_path_100_200_no_coc,recursive=TRUE,pattern = ".txt")
stats_200_no_coc<-lapply(files_names_200_no_coc,function(x)read.table(paste(results_path_100_200_no_coc,x,sep="")))



### 
names(stats_100_no_coc)<-files_names_100_no_coc
lapply(stats_100_no_coc,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc_100

names(stats_200_no_coc)<-files_names_200_no_coc
lapply(stats_200_no_coc,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc_200

names(stats_200_coc_loc)<-files_names_200_coc_loc
lapply(stats_200_coc_loc,function(x){data.frame(x,coc=TRUE)->y;
  return(y)})->TRUE_coc_200


sims<-c("clus_max","clus_min","random","uniform")
FALSE_coc_100<-FALSE_coc_100[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc_100),useBytes=TRUE) ))]
FALSE_coc_200<-FALSE_coc_200[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc_200),useBytes=TRUE) ))]
TRUE_coc_200<-TRUE_coc_200[unlist(sapply(sims,function(x)grep(x,names(TRUE_coc_200),useBytes=TRUE) ))]



lapply(seq(1:4),function(x)data.frame(FALSE_coc_100[[x]],clus_deg=sims[x],locs_num="locs100"))->manova_no_coc_100
lapply(seq(1:4),function(x)data.frame(FALSE_coc_200[[x]],clus_deg=sims[x],locs_num="locs200"))->manova_no_coc_200
lapply(seq(1:4),function(x)data.frame(TRUE_coc_200[[x]],clus_deg=sims[x],locs_num="locs200"))->manova_coc_loc_200



gimme.data<-function(stats){
  stats->stats_4_boxplot
  lapply(stats_4_boxplot[,-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)cbind(stats_4_boxplot[,which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],x))->ciccio_box
  do.call(rbind,ciccio_box)->ciccio_box
  lapply(colnames(stats_4_boxplot)[-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)rep(x,nrow(stats_4_boxplot)))->col_names_box
  unlist(col_names_box)->col_names_box
  data.frame(model_th=col_names_box,ciccio_box)->ciccio_box
  return(ciccio_box)  
}

lapply(manova_no_coc_100,function(x)gimme.data(x))->anova_no_coc_100
lapply(manova_no_coc_200,function(x)gimme.data(x))->anova_no_coc_200
lapply(manova_coc_loc_200,function(x)gimme.data(x))->anova_coc_loc_200


#### MANOVA
do.call(rbind,manova_no_coc_100)->manova_no_coc_100
do.call(rbind,manova_no_coc_200)->manova_no_coc_200
do.call(rbind,manova_coc_loc_200)->manova_coc_loc_200

#### Using data with 100 fossil localities #
library(usdm)
manova_100<-manova_no_coc_100
library(vegan)
#install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
library(pairwiseAdonis)
chosen_axis_100<-min(which(summary(pca_dataset_100<-prcomp(manova_100[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset_100<-pca_dataset_100$x[,1:chosen_axis_100]


ado_res_100<-adonis(pca_dataset_100~clus_deg, data=manova_100,method = "euclidean",permutations = 500,parallel=5)
pw_ado_rest_100<-pairwise.adonis(x=pca_dataset_100,factors=manova_100$"clus_deg",sim.method = "euclidean",perm = 500)

pca_res_100<-prcomp(manova_100[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")])
TukeyHSD(anova_pca_100<-aov(pca_res_100$x[,1]~manova_100$clus_deg))->tukey_100_locs_res




#### Using data with 200 fossil localities #
rbind(manova_no_coc_200,manova_coc_loc_200)->manova_200
library(vegan)
#install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
library(pairwiseAdonis)
chosen_axis_200<-min(which(summary(pca_dataset_200<-prcomp(manova_200[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset_200<-pca_dataset_200$x[,1:chosen_axis_200]


ado_res_200<-adonis(pca_dataset_200~coc+clus_deg, data=manova_200,method = "euclidean",permutations = 500,parallel=5)
pw_ado_rest_200<-pairwise.adonis(x=pca_dataset_200,factors=manova_200$"clus_deg",sim.method = "euclidean",perm = 500)

pca_res_200<-prcomp(manova_200[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")])
TukeyHSD(anova_pca_200<-aov(pca_res_200$x[,1]~manova_200$clus_deg))->tukey_200_locs_res










#### ANOVA using data with 100 fossil localities #
anov_res_no_coc_100<-lapply(anova_no_coc_100,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
  })

#####

#### Tukey
Tukey_res_no_coc_100<-lapply(anov_res_no_coc_100,function(x){
  minosse.others<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.others=minosse.others,minosse.minosse=minosse.minosse)) 
})




#### ANOVA using data with 200 fossil localities and with cooccurrence analysis
# (no significant differences betweeen outputs with and without cooccurrence analysis) #
anov_res_200_coc_loc<-lapply(anova_coc_loc_200,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})

#####

#### Tukey
Tukey_res_200_coc_loc<-lapply(anov_res_200_coc_loc,function(x){
  minosse.others<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.others=minosse.others,minosse.minosse=minosse.minosse)) 
})


# A non-significant result in betadisper is not necessarily 
# related to a significant/non-significant result in adonis. 
# The two tests are testing different hypothesis. The former 
# tests homogeneity of dispersion among groups (regions in your 
#   case), which is a condition (assumption) for adonis. The 
# latter tests no difference in 'location', that is, tests 
# whether composition among groups is similar or not. You may 
# have the centroids of two groups in NMS at a very similar 
# position in the ordination space, but if their dispersions 
# are quite different, adonis will give you a significant 
# p-value, thus, the result is heavily influenced not by the 
# difference in composition between groups but by differences 
# in composition within groups (heterogeneous dispersion, and 
# thus a measure of betadiversity). In short, your results are 
# fine, you are meeting the 'one assumption' for adonis 
# (homogeneous dispersion) and thus you are certain that results
# from adonis are 'real' and not an artifact of heterogeneous 
# dispersions. For more information you can read Anderson (2006) 
# Biometrics 62(1):245-253 and Anderson (2006) Ecology Letters
# 9(6):683-693. Hope this helps!
# from: https://stats.stackexchange.com/questions/212137/betadisper-and-adonis-in-r-am-i-interpreting-my-output-correctly


